<?php
include("config/db.php");

if(isset($_POST['reset'])){
    $username = $_POST['username'];
    $secret = $_POST['secret'];
    $new_password = $_POST['password'];

    // CHECK USER + SECRET
    $check = $conn->query("SELECT * FROM users 
                           WHERE username='$username' AND secret='$secret'");

    if($check->num_rows > 0){
        $conn->query("UPDATE users SET password='$new_password' WHERE username='$username'");
        $msg = "Password reset successful!";
    } else {
        $error = "Invalid username or secret code!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Forgot Password</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body class="login-page">

<div class="login-container">

    <div class="forgot-box">
        <h2>Reset Password</h2>

        <form method="POST">

            <input type="text" name="username" placeholder="Username" required>

            <input type="password" name="secret" placeholder="Secret Code" required>

            <input type="password" name="password" placeholder="New Password" required>

            <button name="reset">Reset Password</button>

        </form>

        <div class="back-link">
            <a href="login.php">Back to Login</a>
        </div>

    </div>

</div>

</body>
</html>