<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit();
}

// FETCH LOGS
$data = $conn->query("
    SELECT * FROM audit_logs 
    ORDER BY timestamp DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Audit Logs</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="sidebar">
    <h2>CityPharma</h2>
      <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="batches.php">Batches</a>
    <a href="suppliers.php">Suppliers</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="payments.php">Payments</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="reports.php">Reports</a>
    <a href="../logout.php">Logout</a>

</div>

<div class="main">
    <h1>Audit Logs</h1>

    <table>
        <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Action</th>
            <th>Table</th>
            <th>Record ID</th>
            <th>Time</th>
        </tr>

        <?php if($data && $data->num_rows > 0): ?>
            <?php while($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['log_id']; ?></td>
                <td><?php echo $row['user_id']; ?></td>
                <td><?php echo $row['action']; ?></td>
                <td><?php echo $row['table_name']; ?></td>
                <td><?php echo $row['record_id']; ?></td>
                <td><?php echo $row['timestamp']; ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">No logs found</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>