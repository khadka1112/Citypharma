<?php
session_start();
include("../config/db.php");



// Session check
if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit();
    if(isset($_GET['delete'])){
    $id = $_GET['delete'];

    $conn->query("DELETE FROM medicines WHERE medicine_id=$id");

    header("Location: medicines.php");
    exit();
    }
}
if(isset($_POST['add'])){
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    $conn->query("INSERT INTO medicines (name, description, price) VALUES ('$name','$desc','$price')");

    // 🔥 IMPORTANT: Redirect after insert
    header("Location: medicines.php");
    exit();
}



// DELETE MEDICINE
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
  $conn->query("DELETE FROM medicines WHERE medicine_id=$id");

}

// FETCH DATA
$result = $conn->query("SELECT * FROM medicines");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Medicines</title>
    <link rel="stylesheet" href="../css/style.css">

   <a href="medicines.php?delete=<?php echo $row['medicine_id']; ?>" 
   onclick="return confirm('Delete this medicine?')">
    
</a>
    
</a>
</a>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2> CityPharma</h2>

    <a href="dashboard.php"> Dashboard</a>
    <a href="medicines.php"> Medicines</a>
    <a href="batches.php"> Batches</a>
    <a href="suppliers.php"> Suppliers</a>
    <a href="prescriptions.php"> Prescriptions</a>
    <a href="prescription_items.php"> Prescription Items</a>
    <a href="dispensing.php"> Dispensing</a>
    <a href="payments.php"> Payments</a>

    <a href="../logout.php"> Logout</a>
</div>

<!-- MAIN -->
<div class="main">
    <h1>Medicines</h1>

    <!-- ADD FORM -->
    <form method="POST">
        <input type="text" name="name" placeholder="Medicine Name" required>
        <input type="text" name="description" placeholder="Description">
        <input type="number" step="0.01" name="price" placeholder="Price (£)" required>
        <button name="add">Add Medicine</button>
    </form>

    <br>

    <!-- TABLE -->
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price (£)</th>
            <th>Action</th>
        </tr>

<?php if($result && $result->num_rows > 0): ?>
    <?php while($row = $result->fetch_assoc()): ?>
   <tr>
    <td><?php echo isset($row['id']) ? $row['id'] : ''; ?></td>
    <td><?php echo isset($row['name']) ? $row['name'] : ''; ?></td>
    <td><?php echo isset($row['description']) ? $row['description'] : ''; ?></td>
    <td><?php echo isset($row['price']) ? $row['price'] : ''; ?></td>
    <td>
        <a href="medicines.php?delete=<?php echo isset($row['id']) ? $row['id'] : 0; ?>" 
           onclick="return confirm('Delete this medicine?')">
            Delete
        </a>
    </td>
</tr>
    <?php endwhile; ?>
<?php endif; ?>

    </table>

</div>

</body>
</html>