<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit();
}

// ADD DISPENSING
if(isset($_POST['add'])){
    $medicine_id = $_POST['medicine_id'];
    $quantity = $_POST['quantity'];

    $conn->query("INSERT INTO dispensing (medicine_id, quantity, date)
                  VALUES ('$medicine_id','$quantity', NOW())");

    header("Location: dispensing.php");
    exit();
}

// DELETE
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM dispensing WHERE dispense_id='$id'");
    header("Location: dispensing.php");
    exit();
}

// FETCH DATA
$data = $conn->query("
    SELECT d.dispense_id, m.name AS medicine, d.quantity, d.date
    FROM dispensing d
    JOIN medicines m ON d.medicine_id = m.medicine_id
");

// DROPDOWN
$medicines = $conn->query("SELECT medicine_id, name FROM medicines");
?>

<!DOCTYPE html>
<html>
<head>
<title>Dispensing</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="sidebar">
    <h2>CityPharma</h2>
     <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="batches.php">Batches</a>
    <a href="suppliers.php">Suppliers</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="payments.php">Payments</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="reports.php">Reports</a>
    <a href="../logout.php">Logout</a>

</div>

<div class="main">
    <h1>Dispensing</h1>

    <!-- FORM -->
    <form method="POST">
        <select name="medicine_id" required>
            <option value="">Select Medicine</option>
            <?php while($m = $medicines->fetch_assoc()): ?>
                <option value="<?php echo $m['medicine_id']; ?>">
                    <?php echo $m['name']; ?>
                </option>
            <?php endwhile; ?>
        </select>

        <input type="number" name="quantity" placeholder="Quantity" required>

        <button name="add">Dispense</button>
    </form>

    <br>

    <!-- TABLE -->
    <table>
        <tr>
            <th>ID</th>
            <th>Medicine</th>
            <th>Quantity</th>
            <th>Date</th>
            <th>Action</th>
        </tr>

        <?php if($data && $data->num_rows > 0): ?>
            <?php while($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['dispense_id']; ?></td>
                <td><?php echo $row['medicine']; ?></td>
                <td><?php echo $row['quantity']; ?></td>
                <td><?php echo $row['date']; ?></td>
                <td>
                    <a href="dispensing.php?delete=<?php echo $row['dispense_id']; ?>" 
                       onclick="return confirm('Delete?')">
                        Delete
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">No data</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>