<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit();
}

// ADD BATCH
if(isset($_POST['add'])){
    $medicine_id = $_POST['medicine_id'];
    $batch_number = $_POST['batch_number'];
    $expiry_date = $_POST['expiry_date'];
    $quantity = $_POST['quantity'];

    $conn->query("INSERT INTO batches (medicine_id, batch_number, expiry_date, quantity)
                  VALUES ('$medicine_id','$batch_number','$expiry_date','$quantity')");

    header("Location: batches.php");
    exit();
}

// DELETE BATCH
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM batches WHERE batch_id='$id'");
    header("Location: batches.php");
    exit();
}

// FETCH DATA
$data = $conn->query("
    SELECT b.batch_id, m.name AS medicine, b.batch_number, b.expiry_date, b.quantity
    FROM batches b
    JOIN medicines m ON b.medicine_id = m.medicine_id
");

// DROPDOWN
$medicines = $conn->query("SELECT medicine_id, name FROM medicines");
?>

<!DOCTYPE html>
<html>
<head>
<title>Batches</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>CityPharma</h2>
     <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="batches.php">Batches</a>
    <a href="suppliers.php">Suppliers</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="payments.php">Payments</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="reports.php">Reports</a>
    <a href="../logout.php">Logout</a>

</div>

<!-- MAIN -->
<div class="main">
    <h1>Batches</h1>

    <!-- FORM -->
    <form method="POST">
        <select name="medicine_id" required>
            <option value="">Select Medicine</option>
            <?php while($m = $medicines->fetch_assoc()): ?>
                <option value="<?php echo $m['medicine_id']; ?>">
                    <?php echo $m['name']; ?>
                </option>
            <?php endwhile; ?>
        </select>

        <input type="text" name="batch_number" placeholder="Batch Number" required>
        <input type="date" name="expiry_date" required>
        <input type="number" name="quantity" placeholder="Quantity" required>

        <button name="add">Add Batch</button>
    </form>

    <br>

    <!-- TABLE -->
    <table>
        <tr>
            <th>ID</th>
            <th>Medicine</th>
            <th>Batch Number</th>
            <th>Expiry Date</th>
            <th>Quantity</th>
            <th>Action</th>
        </tr>

        <?php if($data && $data->num_rows > 0): ?>
            <?php while($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['batch_id']; ?></td>
                <td><?php echo $row['medicine']; ?></td>
                <td><?php echo $row['batch_number']; ?></td>
                <td><?php echo $row['expiry_date']; ?></td>
                <td><?php echo $row['quantity']; ?></td>
                <td>
                    <a href="batches.php?delete=<?php echo $row['batch_id']; ?>" 
                       onclick="return confirm('Delete batch?')">
                        Delete
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">No batches found</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>