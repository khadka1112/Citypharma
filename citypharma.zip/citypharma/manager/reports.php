<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit();
}

// ===== SUMMARY =====
$sales = $conn->query("SELECT SUM(amount) as total FROM payments")->fetch_assoc();
$medicines = $conn->query("SELECT COUNT(*) as total FROM medicines")->fetch_assoc();
$suppliers = $conn->query("SELECT COUNT(*) as total FROM suppliers")->fetch_assoc();
$prescriptions = $conn->query("SELECT COUNT(*) as total FROM prescriptions")->fetch_assoc();

// LOW STOCK (LESS THAN 10)
$low_stock = $conn->query("
    SELECT m.name, b.quantity 
    FROM batches b
    JOIN medicines m ON b.medicine_id = m.medicine_id
    WHERE b.quantity < 10
");

// RECENT PAYMENTS
$recent = $conn->query("
    SELECT * FROM payments 
    ORDER BY payment_date DESC 
    LIMIT 5
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Reports</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>CityPharma</h2>

    <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="batches.php">Batches</a>
    <a href="suppliers.php">Suppliers</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="payments.php">Payments</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="reports.php">Reports</a>
    <a href="../logout.php">Logout</a>
</div>

<!-- MAIN -->
<div class="main">
    <h1>Reports</h1>

    <!-- SUMMARY -->
    <div class="cards">

        <div class="card">
            <h3>Total Sales</h3>
            <p>£<?= $sales['total'] ?? 0 ?></p>
        </div>

        <div class="card">
            <h3>Total Medicines</h3>
            <p><?= $medicines['total'] ?></p>
        </div>

        <div class="card">
            <h3>Total Suppliers</h3>
            <p><?= $suppliers['total'] ?></p>
        </div>

        <div class="card">
            <h3>Total Prescriptions</h3>
            <p><?= $prescriptions['total'] ?></p>
        </div>

    </div>

    <br>

    <!-- LOW STOCK -->
    <h2>⚠ Low Stock Medicines</h2>

    <table>
        <tr>
            <th>Medicine</th>
            <th>Quantity</th>
        </tr>

        <?php if($low_stock && $low_stock->num_rows > 0): ?>
            <?php while($row = $low_stock->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['quantity']; ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="2">No low stock</td>
            </tr>
        <?php endif; ?>
    </table>

    <br>

    <!-- RECENT PAYMENTS -->
    <h2>Recent Payments</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Amount (£)</th>
            <th>Purpose</th>
            <th>Date</th>
        </tr>

        <?php if($recent && $recent->num_rows > 0): ?>
            <?php while($row = $recent->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['payment_id']; ?></td>
                <td><?php echo $row['amount']; ?></td>
                <td><?php echo $row['purpose']; ?></td>
                <td><?php echo $row['payment_date']; ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">No payments</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>