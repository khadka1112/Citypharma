<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit();
}

// ADD SUPPLIER
if(isset($_POST['add'])){
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    $company_name = $_POST['company_name'];

    $conn->query("INSERT INTO suppliers (name, contact, address, company_name)
                  VALUES ('$name','$contact','$address','$company_name')");

    header("Location: suppliers.php");
    exit();
}

// DELETE SUPPLIER
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM suppliers WHERE supplier_id='$id'");
    header("Location: suppliers.php");
    exit();
}

// FETCH DATA
$data = $conn->query("SELECT * FROM suppliers");
?>

<!DOCTYPE html>
<html>
<head>
<title>Suppliers</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>CityPharma</h2>
    

    <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="batches.php">Batches</a>
    <a href="suppliers.php">Suppliers</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="payments.php">Payments</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="reports.php">Reports</a>
    <a href="../logout.php">Logout</a>

</div>

<!-- MAIN -->
<div class="main">
    <h1>Suppliers</h1>

    <!-- FORM -->
    <form method="POST">
        <input type="text" name="name" placeholder="Supplier Name" required>
        <input type="text" name="contact" placeholder="Contact Number" required>
        <input type="text" name="address" placeholder="Address" required>
        <input type="text" name="company_name" placeholder="Company Name" required>

        <button name="add">Add Supplier</button>
    </form>

    <br>

    <!-- TABLE -->
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Contact</th>
            <th>Address</th>
            <th>Company</th>
            <th>Action</th>
        </tr>

        <?php if($data && $data->num_rows > 0): ?>
            <?php while($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['supplier_id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['contact']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td><?php echo $row['company_name']; ?></td>
                <td>
                    <a href="suppliers.php?delete=<?php echo $row['supplier_id']; ?>" 
                       onclick="return confirm('Delete supplier?')">
                        Delete
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">No suppliers found</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>