<?php
session_start();
include("../config/db.php");

// CHECK LOGIN
if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit();
}

// ===== DATA QUERIES (IMPORTANT - MUST BE HERE) =====

// TOTAL SALES
$sales = $conn->query("SELECT SUM(amount) as total FROM payments")->fetch_assoc();

// COUNTS
$medicines = $conn->query("SELECT COUNT(*) as total FROM medicines")->fetch_assoc();
$suppliers = $conn->query("SELECT COUNT(*) as total FROM suppliers")->fetch_assoc();
$prescriptions = $conn->query("SELECT COUNT(*) as total FROM prescriptions")->fetch_assoc();
$batches = $conn->query("SELECT COUNT(*) as total FROM batches")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>CityPharma</h2>

    <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="batches.php">Batches</a>
    <a href="suppliers.php">Suppliers</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="payments.php">Payments</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="#">Reports</a>
    <a href="../logout.php">Logout</a>
</div>

<!-- MAIN -->
<div class="main">

    <!-- HEADER -->
    <div class="header">
        <h1>DASHBOARD</h1>
        <p>Welcome Manager</p>
    </div>

    <!-- CARDS -->
    <div class="cards">

        <div class="card">
            <h3>Total Sales</h3>
            <p>£<?= $sales['total'] ?? 0 ?></p>
        </div>

        <div class="card">
            <h3>Medicines</h3>
            <p><?= $medicines['total'] ?? 0 ?></p>
        </div>

        <div class="card">
            <h3>Suppliers</h3>
            <p><?= $suppliers['total'] ?? 0 ?></p>
        </div>

        <div class="card">
            <h3>Prescriptions</h3>
            <p><?= $prescriptions['total'] ?? 0 ?></p>
        </div>

        <div class="card">
            <h3>Batches</h3>
            <p><?= $batches['total'] ?? 0 ?></p>
        </div>

    </div>

</div>

</body>
</html>