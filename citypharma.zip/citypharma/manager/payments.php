<?php
session_start();
include("../config/db.php");

// CHECK LOGIN
if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit();
}

// ADD PAYMENT
if(isset($_POST['add'])){
    $amount = $_POST['amount'];
    $purpose = $_POST['purpose'];
    $medicine_id = $_POST['medicine_id'];
    $quantity = $_POST['quantity'];

    // INSERT PAYMENT
    $conn->query("INSERT INTO payments (amount, payment_date, purpose)
                  VALUES ('$amount', NOW(), '$purpose')");

    $payment_id = $conn->insert_id;

    // REDUCE STOCK
    $conn->query("UPDATE batches 
                  SET quantity = quantity - $quantity 
                  WHERE medicine_id = '$medicine_id' 
                  LIMIT 1");

    // AUDIT LOG (SAFE)
    if(isset($_SESSION['user_id'])){
        $user_id = $_SESSION['user_id'];

        $conn->query("INSERT INTO audit_logs (user_id, action, table_name, record_id)
        VALUES ('$user_id', 'INSERT', 'payments', '$payment_id')");
    }

    header("Location: payments.php");
    exit();
}

// DELETE PAYMENT
if(isset($_GET['delete'])){
    $id = $_GET['delete'];

    $conn->query("DELETE FROM payments WHERE payment_id='$id'");

    // AUDIT LOG
    if(isset($_SESSION['user_id'])){
        $user_id = $_SESSION['user_id'];

        $conn->query("INSERT INTO audit_logs (user_id, action, table_name, record_id)
        VALUES ('$user_id', 'DELETE', 'payments', '$id')");
    }

    header("Location: payments.php");
    exit();
}

// FETCH PAYMENTS
$data = $conn->query("SELECT * FROM payments");

// TOTAL SALES
$total = $conn->query("SELECT SUM(amount) as total FROM payments")->fetch_assoc();

// MEDICINES DROPDOWN
$medicines = $conn->query("SELECT medicine_id, name FROM medicines");
?>

<!DOCTYPE html>
<html>
<head>
<title>Payments</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>CityPharma</h2>
      <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="batches.php">Batches</a>
    <a href="suppliers.php">Suppliers</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="payments.php">Payments</a>
    <a href="audit_logs.php">Audit Logs</a>
    <a href="reports.php">Reports</a>
    <a href="../logout.php">Logout</a>

</div>

<!-- MAIN -->
<div class="main">
    <h1>Payments</h1>

    <!-- TOTAL SALES -->
    <h3>Total Sales: £<?php echo $total['total'] ?? 0; ?></h3>

    <!-- FORM -->
    <form method="POST">

        <input type="number" step="0.01" name="amount" placeholder="Enter Amount (£)" required>

        <input type="text" name="purpose" placeholder="Purpose (e.g. Sold Medicine)" required>

        <select name="medicine_id" required>
            <option value="">Select Medicine</option>
            <?php while($m = $medicines->fetch_assoc()): ?>
                <option value="<?php echo $m['medicine_id']; ?>">
                    <?php echo $m['name']; ?>
                </option>
            <?php endwhile; ?>
        </select>

        <input type="number" name="quantity" placeholder="Quantity Sold" required>

        <button name="add">Add Payment</button>
    </form>

    <br>

    <!-- TABLE -->
    <table>
        <tr>
            <th>ID</th>
            <th>Amount (£)</th>
            <th>Purpose</th>
            <th>Date</th>
            <th>Action</th>
        </tr>

        <?php if($data && $data->num_rows > 0): ?>
            <?php while($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['payment_id']; ?></td>
                <td><?php echo $row['amount']; ?></td>
                <td><?php echo $row['purpose']; ?></td>
                <td><?php echo $row['payment_date']; ?></td>
                <td>
                    <a href="payments.php?delete=<?php echo $row['payment_id']; ?>" 
                       onclick="return confirm('Delete payment?')">
                        Delete
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">No payments found</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>