<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit();
}

// ADD PRESCRIPTION
if(isset($_POST['add'])){
    $patient_name = $_POST['patient_name'];
    $doctor_name = $_POST['doctor_name'];
    $date = $_POST['date'];

    $conn->query("INSERT INTO prescriptions (patient_name, doctor_name, date)
                  VALUES ('$patient_name','$doctor_name','$date')");

    header("Location: prescriptions.php");
    exit();
}

// DELETE PRESCRIPTION (FIXED)
if(isset($_GET['delete'])){
    $id = $_GET['delete'];

    // DELETE CHILD FIRST (IMPORTANT)
    $conn->query("DELETE FROM prescription_items WHERE prescription_id='$id'");

    // THEN DELETE PARENT
    $conn->query("DELETE FROM prescriptions WHERE prescription_id='$id'");

    header("Location: prescriptions.php");
    exit();
}

// FETCH DATA
$data = $conn->query("SELECT * FROM prescriptions");
?>

<!DOCTYPE html>
<html>
<head>
<title>Prescriptions</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
     <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="payments.php">Payments</a>
    
    <a href="../logout.php">Logout</a>

</div>

<!-- MAIN -->
<div class="main">
    <h1>Prescriptions</h1>

    <!-- FORM -->
    <form method="POST">
        <input type="text" name="patient_name" placeholder="Patient Name" required>
        <input type="text" name="doctor_name" placeholder="Doctor Name" required>
        <input type="date" name="date" required>

        <button name="add">Add Prescription</button>
    </form>

    <br>

    <!-- TABLE -->
    <table>
        <tr>
            <th>ID</th>
            <th>Patient Name</th>
            <th>Doctor</th>
            <th>Date</th>
           
        </tr>

        <?php if($data && $data->num_rows > 0): ?>
            <?php while($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['prescription_id']; ?></td>
                <td><?php echo $row['patient_name']; ?></td>
                <td><?php echo $row['doctor_name']; ?></td>
                <td><?php echo $row['date']; ?></td>
                <td>
                   
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">No prescriptions found</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>