<?php
session_start();

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'staff'){
    header("Location: ../login.php");
    exit();
}

include("../config/db.php");

// Data
$medicines = $conn->query("SELECT COUNT(*) as total FROM medicines")->fetch_assoc();
$prescriptions = $conn->query("SELECT COUNT(*) as total FROM prescriptions")->fetch_assoc();
$dispensing = $conn->query("SELECT COUNT(*) as total FROM dispensing")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Staff Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2> Staff Panel</h2>

    <a href="dashboard.php"> Dashboard</a>
    <a href="medicines.php"> Medicines</a>
    <a href="prescriptions.php"> Prescriptions</a>
    <a href="prescription_items.php"> Prescription Items</a>
    <a href="dispensing.php"> Dispensing</a>
    <a href="payments.php"> Payments</a>

    <a href="../logout.php"> Logout</a>
</div>

<!-- MAIN -->
<div class="main">

    <div class="header">
        <h1>Staff Dashboard</h1>
        <p>Welcome Staff </p>
    </div>

    <div class="cards">

        <div class="card">
            <h3> Medicines</h3>
            <p><?= $medicines['total'] ?></p>
        </div>

        <div class="card">
            <h3>Prescriptions</h3>
            <p><?= $prescriptions['total'] ?></p>
        </div>

        <div class="card">
            <h3>Dispensing</h3>
            <p><?= $dispensing['total'] ?></p>
        </div>

    </div>

</div>

</body>
</html>