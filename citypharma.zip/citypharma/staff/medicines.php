<?php
session_start();
include("../config/db.php");

// ONLY STAFF ACCESS
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'staff'){
    header("Location: ../login.php");
    exit();
}

// FETCH MEDICINES
$data = $conn->query("SELECT * FROM medicines");
?>

<!DOCTYPE html>
<html>
<head>
<title>Medicines</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>CityPharma (Staff)</h2>

    <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="../logout.php">Logout</a>
</div>

<!-- MAIN -->
<div class="main">
    <h1>Medicines (View Only)</h1>

    <!-- TABLE -->
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price (£)</th>
        </tr>

        <?php if($data && $data->num_rows > 0): ?>
            <?php while($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['medicine_id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['description']; ?></td>
                <td><?php echo $row['price']; ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">No medicines found</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>