<?php
session_start();
include("../config/db.php");

// ONLY STAFF
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'staff'){
    header("Location: ../login.php");
    exit();
}

// ADD ITEM
if(isset($_POST['add'])){
    $prescription_id = $_POST['prescription_id'];
    $medicine_id = $_POST['medicine_id'];
    $quantity = $_POST['quantity'];

    $conn->query("INSERT INTO prescription_items (prescription_id, medicine_id, quantity)
                  VALUES ('$prescription_id', '$medicine_id', '$quantity')");

    header("Location: prescription_items.php");
    exit();
}

// DELETE ITEM (optional for staff)


   
// FETCH DATA
$data = $conn->query("
    SELECT 
        pi.item_id,
        p.patient_name,
        m.name AS medicine,
        pi.quantity
    FROM prescription_items pi
    JOIN prescriptions p ON pi.prescription_id = p.prescription_id
    JOIN medicines m ON pi.medicine_id = m.medicine_id
");

// DROPDOWNS
$prescriptions = $conn->query("SELECT prescription_id, patient_name FROM prescriptions");
$medicines = $conn->query("SELECT medicine_id, name FROM medicines");
?>

<!DOCTYPE html>
<html>
<head>
<title>Prescription Items</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>CityPharma (Staff)</h2>

    <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="../logout.php">Logout</a>
</div>

<!-- MAIN -->
<div class="main">
    <h1>Prescription Items</h1>

    <!-- FORM -->
    <form method="POST">

        <select name="prescription_id" required>
            <option value="">Select Prescription</option>
            <?php while($p = $prescriptions->fetch_assoc()): ?>
                <option value="<?php echo $p['prescription_id']; ?>">
                    <?php echo $p['patient_name']; ?>
                </option>
            <?php endwhile; ?>
        </select>

        <select name="medicine_id" required>
            <option value="">Select Medicine</option>
            <?php while($m = $medicines->fetch_assoc()): ?>
                <option value="<?php echo $m['medicine_id']; ?>">
                    <?php echo $m['name']; ?>
                </option>
            <?php endwhile; ?>
        </select>

        <input type="number" name="quantity" placeholder="Quantity" required>

        <button name="add">Add Item</button>
    </form>

    <br>

    <!-- TABLE -->
    <table>
        <tr>
            <th>ID</th>
            <th>Patient</th>
            <th>Medicine</th>
            <th>Quantity</th>
            
        </tr>

        <?php if($data && $data->num_rows > 0): ?>
            <?php while($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['item_id']; ?></td>
                <td><?php echo $row['patient_name']; ?></td>
                <td><?php echo $row['medicine']; ?></td>
                <td><?php echo $row['quantity']; ?></td>
                <td>
                    <a href="prescription_items.php?delete=<?php echo $row['item_id']; ?>"
                       onclick="return confirm('Delete item?')">
                        Delete
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">No items found</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>