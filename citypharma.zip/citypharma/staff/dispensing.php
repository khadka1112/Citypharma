<?php
session_start();
include("../config/db.php");

// ONLY STAFF
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'staff'){
    header("Location: ../login.php");
    exit();
}

// ADD DISPENSING
if(isset($_POST['add'])){
    $medicine_id = $_POST['medicine_id'];
    $quantity = $_POST['quantity'];

    // CHECK STOCK FIRST
    $stock = $conn->query("
        SELECT quantity FROM batches 
        WHERE medicine_id='$medicine_id' 
        LIMIT 1
    ")->fetch_assoc();

    if($stock && $stock['quantity'] >= $quantity){

        // INSERT DISPENSING
        $conn->query("INSERT INTO dispensing (medicine_id, quantity, date)
                      VALUES ('$medicine_id', '$quantity', NOW())");

        // REDUCE STOCK
        $conn->query("UPDATE batches 
                      SET quantity = quantity - $quantity 
                      WHERE medicine_id='$medicine_id' 
                      LIMIT 1");

        header("Location: dispensing.php");
        exit();

    } else {
        $error = "Not enough stock!";
    }
}

// FETCH DATA
$data = $conn->query("
    SELECT d.dispense_id, m.name, d.quantity, d.date
    FROM dispensing d
    JOIN medicines m ON d.medicine_id = m.medicine_id
    ORDER BY d.dispense_id DESC
");

// MEDICINES DROPDOWN
$medicines = $conn->query("SELECT medicine_id, name FROM medicines");
?>

<!DOCTYPE html>
<html>
<head>
<title>Dispensing</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>CityPharma (Staff)</h2>

    <a href="dashboard.php">Dashboard</a>
    <a href="medicines.php">Medicines</a>
    <a href="prescriptions.php">Prescriptions</a>
    <a href="prescription_items.php">Prescription Items</a>
    <a href="dispensing.php">Dispensing</a>
    <a href="../logout.php">Logout</a>
</div>

<!-- MAIN -->
<div class="main">
    <h1>Dispensing</h1>

    <!-- ERROR MESSAGE -->
    <?php if(isset($error)): ?>
        <p style="color:red;"><?php echo $error; ?></p>
    <?php endif; ?>

    <!-- FORM -->
    <form method="POST">

        <select name="medicine_id" required>
            <option value="">Select Medicine</option>
            <?php while($m = $medicines->fetch_assoc()): ?>
                <option value="<?php echo $m['medicine_id']; ?>">
                    <?php echo $m['name']; ?>
                </option>
            <?php endwhile; ?>
        </select>

        <input type="number" name="quantity" placeholder="Quantity" required>

        <button name="add">Dispense</button>
    </form>

    <br>

    <!-- TABLE -->
    <table>
        <tr>
            <th>ID</th>
            <th>Medicine</th>
            <th>Quantity</th>
            <th>Date</th>
        </tr>

        <?php if($data && $data->num_rows > 0): ?>
            <?php while($row = $data->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['dispense_id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['quantity']; ?></td>
                <td><?php echo $row['date']; ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">No records</td>
            </tr>
        <?php endif; ?>
    </table>

</div>

</body>
</html>