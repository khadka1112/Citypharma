<?php
session_start();
include("config/db.php");

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($query);

    if($result->num_rows > 0){
        $user = $result->fetch_assoc();

        $_SESSION['role'] = $user['role'];
        $_SESSION['user_id'] = $user['user_id'];

        if($user['role'] == 'manager'){
            header("Location: manager/dashboard.php");
        } else {
            header("Location: staff/dashboard.php");
        }
        exit();
    } else {
        $error = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>CityPharma Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<!-- ✅ ONLY ONE BODY -->
<body class="login-page">

<div class="login-container">

    <div class="login-box">
        <h2>Welcome to CityPharma</h2>
        <p class="subtitle">Login to the Pharmacy Management System</p>

        <?php if(isset($error)) echo "<p class='error'>$error</p>"; ?>

        <form method="POST">

            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Enter username" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter password" required>
            </div>

            <button name="login">Login</button>

            <!-- ✅ CORRECT LINK -->
            <div class="extra-links">
                <a href="forgot_password.php">Forgot Password?</a>
            </div>

        </form>
    </div>

</div>

<!-- FOOTER -->
<footer>
    © <?php echo date("Y"); ?> CityPharma. All rights reserved  
    <br>Designed by Pradeep</br>
</footer>

</body>
</html>